package br.ulbra.entity;

import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author aluno.saolucas
 */
public class Numeros {

    public ArrayList<Integer> numerosAr;

    public Numeros() {
        numerosAr = new ArrayList<Integer>();
    }

    public void adicionar(int numero) {
        numerosAr.add(numero);
        System.out.println(numero + "Número adicionado com sucesso!");
    }

    public String getNumeros() {
        String lista = "Lista e Números \n";
        if (!numerosAr.isEmpty()) {
            for (int i = 0; i < numerosAr.size(); i++) {
                lista += (i + 1) + "-" + numerosAr.get(i) + "\n";
            }

        }
        return lista;
    }

    public void excluir(int i) {
        if (!numerosAr.isEmpty()) {

            if ((i - 1 >= 0) && (i - 1) < numerosAr.size()) {
                numerosAr.remove(i - 1);
                JOptionPane.showMessageDialog(null, "Número excluido com sucesso!");
            } else {
                JOptionPane.showMessageDialog(null, "O regitro não existe!");
            }

        } else {
            JOptionPane.showMessageDialog(null, " A Lista está vazia");
        }
    }

    public void alterar(int i, int novoNum) {

        if (!numerosAr.isEmpty()) {

            if ((i - 1 >= 0) && (i - 1) < numerosAr.size()) {

                numerosAr.set(i - 1, novoNum);
            } else {

                JOptionPane.showMessageDialog(null, "Registro foi alterado com sucesso!!");
            }
        } else {
            JOptionPane.showMessageDialog(null, "A lista vazia");
        }
    }

    public int pequisar(int elemento) {
        boolean achou = false;
        int i = 0;
        int n = 0;

        if (!numerosAr.isEmpty()) {
            while (i < numerosAr.size() && !achou) {
                if (elemento == numerosAr.get(i)) {
                    n = elemento;
                    achou = true;
                } else {
                    i++;
                }
            }
            if (!achou) {
                JOptionPane.showMessageDialog(null,"Valor inxitnte na lista!");
            }
        }
        return n;
    }
}
