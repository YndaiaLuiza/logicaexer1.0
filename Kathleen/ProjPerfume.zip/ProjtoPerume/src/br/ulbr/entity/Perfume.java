package br.ulbr.entity;

import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author Kathleen
 */
public class Perfume {

    public ArrayList perfumes;

    public Perfume() {
        perfumes = new ArrayList();
    }

    public void salvar(String nome) {
        perfumes.add(nome);
        JOptionPane.showMessageDialog(null, nome + " Salvo com sucesso!");
    }

    public String getPerfumes() {
        String lista = "Lista de perfumes\n";
        if (!perfumes.isEmpty()) {
            for (int i = 0; i < perfumes.size(); i++) {
                lista += (i+1) + "-" + perfumes.get(i) + "\n";
            }
        }else{
            lista= "Lista encontra-se vazia!";}
    
        return lista;
    }
}
