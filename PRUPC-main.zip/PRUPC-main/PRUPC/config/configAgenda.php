<?php
    include_once "../classes/Database.php"; 
    $database = new Database(); 
    $db = $database->getConnection();
?>